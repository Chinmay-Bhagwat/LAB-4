import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calulate-function',
  templateUrl: './calulate-function.component.html',
  styleUrls: ['./calulate-function.component.css']
})
export class CalulateFunctionComponent implements OnInit {

  num1: number = 0;
  num2: number = 0;
  answer: number = 0;


  constructor() { }

  ngOnInit(): void {
  }

  addHandler(){
    this.answer = parseInt(this.num1 + "")  + parseInt(this.num2 + "");
  }

  substractionHandler(){
    this.answer = this.num1 - this.num2;
  }

  multiplicationHandler(){
    this.answer = this.num1 * this.num2;
  }

  divisionHandler(){
    this.answer = this.num1 / this.num2;
  }

  clearSelectionHandler(){
    this.answer = 0;
    this.num1 = 0;
    this.num2 = 0;
  }

}
